# 底盘悬架平台创新提案

给底盘悬架工程师用的一套写法：把平台上的创新点收成内部评审幻灯片，并同时生成技术交底书骨架，方便后面做专利检索和撰写。

它不检索，也不判断能不能授权。没有试验的地方保持“待测”。

## 在 Cursor 里用

技能在 `.cursor/skills/chassis-suspension-innovation-ppt/`。在这个项目里直接说“按悬架平台创新提案技能，做一版 PPT”即可。

技能会先确认桥、基线、不能动的安装点和你已经有的结构，再把能单独交底的方案写成提案。过不了过滤器的想法会写进“本次不写进交底”，不会被编成一条权利要求。

## 本地运行

```bash
python3 -m pip install -r requirements.txt
python3 -m pytest
python3 -m pptgen examples/e-platform-rear/proposal.yaml --out-dir examples/e-platform-rear
```

输出：

- `examples/e-platform-rear/E平台后悬架创新提案.pptx`
- `examples/e-platform-rear/E平台后悬架创新提案-交底骨架.md`

幻灯片指定微软雅黑。中文 Windows 上的 PowerPoint 和 WPS 可以直接打开。

只校验、不生成文件：

```bash
python3 -m pptgen examples/e-platform-rear/proposal.yaml --check
```

真实项目不要改这个示例。复制 YAML，把 `meta.example` 设为 `false`，换上自己的平台边界和结构。字段说明在技能的 `references/schema.md`。

## 示例讲什么

示例是一个虚构的纯电后悬架模块，用来示范写法，不是某个主机厂的项目，也没有测量数据。

三案各管一件事：

1. 电机反力不要再带动控制臂内点硬点。检索风险中。
2. 抬车高时，弹簧座和内点走两条不平行的位移。检索风险中。
3. 用斜孔把驱动纵向力送进衬套轴向。斜置衬套是拥挤区，示例的结论是先检索、先不写交底。

## 默认约定

- 乘用车悬架，不是商用车或摩托车。技能会在真实项目里问前悬还是后悬。
- 评审语言用中文。
- 一次评审一到四个能单独成立的装置方案。空白挖掘时通常是两到三个，不凑数。
- 结构关系优先。没有新结构的控制算法不单独立案。
- 不编试验数据、专利公开号和供应商。

如果实际基线是扭力梁、整体桥或商用车悬架，不要沿用示例的三案，按技能重新写矛盾和必要特征。
